
"""
CodeAlpha - TASK 4: Disease Prediction from Medical Data (Breast Cancer)
Author: Auto-generated
Description:
    Train several classifiers on scikit-learn's breast cancer dataset.
    Evaluate using Precision, Recall, F1, ROC-AUC. Save figures & metrics.
"""

import os, json, math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    precision_score, recall_score, f1_score, roc_auc_score,
    confusion_matrix, classification_report, roc_curve, auc
)
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier

RANDOM_STATE = 42

def plot_roc_curves(models, X_test, y_test, outpath):
    plt.figure()
    for name, model in models.items():
        if hasattr(model, "predict_proba"):
            y_score = model.predict_proba(X_test)[:, 1]
        else:
            if hasattr(model, "decision_function"):
                scores = model.decision_function(X_test)
                s_min, s_max = scores.min(), scores.max()
                y_score = (scores - s_min) / (s_max - s_min) if s_max > s_min else np.zeros_like(scores)
            else:
                continue
        fpr, tpr, _ = roc_curve(y_test, y_score)
        plt.plot(fpr, tpr, label=f"{name} (AUC={auc(fpr,tpr):.3f})")

    plt.plot([0,1],[0,1],'--')
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curves — Breast Cancer")
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(outpath, dpi=160)
    plt.close()

def plot_confusion(cm, outpath, title="Confusion Matrix"):
    fig = plt.figure()
    ax = fig.add_subplot(111)
    im = ax.imshow(cm, interpolation="nearest")
    ax.set_title(title)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, cm[i, j], ha="center", va="center")
    fig.tight_layout()
    fig.savefig(outpath, dpi=160)
    plt.close(fig)

def main():
    out_dir = os.path.dirname(__file__)
    project_dir = os.path.abspath(os.path.join(out_dir, os.pardir))
    figs_dir = os.path.join(project_dir, "figures")

    data = load_breast_cancer()
    X = pd.DataFrame(data.data, columns=data.feature_names)
    y = pd.Series(data.target)  # 0 = malignant, 1 = benign

    num_feats = list(X.columns)
    preprocessor = ColumnTransformer([
        ("num", StandardScaler(), num_feats)
    ])

    models = {
        "LogisticRegression": LogisticRegression(max_iter=500, solver="lbfgs"),
        "SVC": SVC(kernel="rbf", probability=True, random_state=RANDOM_STATE),
        "RandomForest": RandomForestClassifier(n_estimators=300, random_state=RANDOM_STATE),
        "GradientBoosting": GradientBoostingClassifier(random_state=RANDOM_STATE)
    }

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE
    )

    fitted = {}
    metrics = {}
    for name, clf in models.items():
        pipe = Pipeline([("prep", preprocessor), ("clf", clf)])
        pipe.fit(X_train, y_train)
        y_pred = pipe.predict(X_test)

        # proba for ROC
        if hasattr(pipe.named_steps["clf"], "predict_proba"):
            y_proba = pipe.predict_proba(X_test)[:,1]
        else:
            scores = pipe.decision_function(X_test)
            s_min, s_max = scores.min(), scores.max()
            y_proba = (scores - s_min) / (s_max - s_min) if s_max > s_min else np.zeros_like(scores)

        pr = precision_score(y_test, y_pred)
        rc = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        roc = roc_auc_score(y_test, y_proba)

        metrics[name] = {
            "precision": float(pr),
            "recall": float(rc),
            "f1": float(f1),
            "roc_auc": float(roc),
            "report": classification_report(y_test, y_pred, output_dict=False)
        }
        fitted[name] = pipe

    with open(os.path.join(project_dir, "metrics_report.json"), "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)

    plot_roc_curves(fitted, X_test, y_test, os.path.join(figs_dir, "roc_curves.png"))

    best_name = max(metrics, key=lambda k: metrics[k]["roc_auc"])
    best_pipe = fitted[best_name]
    y_pred_best = best_pipe.predict(X_test)
    cm = confusion_matrix(y_test, y_pred_best)
    plot_confusion(cm, os.path.join(figs_dir, "confusion_matrix_best.png"), title=f"Confusion Matrix — {best_name}")

    print("=== Breast Cancer — Test Metrics ===")
    for name, m in metrics.items():
        print(f"\n{name}:")
        for k in ["precision","recall","f1","roc_auc"]:
            print(f"  {k}: {m[k]:.4f}")
    print(f"\nBest model (ROC-AUC): {best_name}")

if __name__ == "__main__":
    main()
