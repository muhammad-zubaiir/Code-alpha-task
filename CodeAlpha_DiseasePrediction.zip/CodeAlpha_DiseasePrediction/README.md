# CodeAlpha — Machine Learning Tasks

This repository contains two completed tasks per the **Machine Learning Tasks & Instructions — CodeAlpha** PDF:

- **TASK 1: Credit Scoring Model**
- **TASK 4: Disease Prediction from Medical Data (Breast Cancer)**

Both projects include: clean Python code, training & evaluation, ROC curves, confusion matrices, and clear READMEs.


## Project: Disease Prediction from Medical Data (Breast Cancer)

### Objective
Predict the presence of breast cancer using the scikit-learn breast cancer dataset (structured medical data).

### Approach
- Algorithms: Logistic Regression, Support Vector Machine (SVC), Random Forest, Gradient Boosting.
- Preprocessing: Standard scaling for linear models; stratified train/test split.
- Metrics: **Precision, Recall, F1-Score, ROC-AUC**.
- Visuals: ROC curves across models; confusion matrix for best model by ROC-AUC.

### How to Run
```bash
# (optional) create venv
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate

# install
pip install -r requirements.txt

# run
python src/train_disease_model.py
```

Outputs (saved in `figures/`):
- `roc_curves.png`
- `confusion_matrix_best.png`

Metrics are printed to the console and also saved to `metrics_report.json`.
